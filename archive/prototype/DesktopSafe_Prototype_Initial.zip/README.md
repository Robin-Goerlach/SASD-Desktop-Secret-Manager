# DesktopSafe

DesktopSafe ist **kein binärkompatibler `.psafe3`-Klon**, sondern ein **sauber strukturierter, kommentierter, Password-Safe-inspirierter C#-Desktop-Prototyp**.

## Ziele

- verständlicher Code
- viele `///` XML-Kommentare
- viele erklärende `//` Kommentare
- klare Trennung von Modell, Kryptografie, Dateizugriff und UI
- gut als Lernbasis für einen späteren professionelleren Passwortmanager geeignet

## Technische Eckpunkte

- .NET 8
- WinForms Desktop-Anwendung
- AES-256-GCM
- PBKDF2-SHA256
- verschlüsselte Datei im JSON-Hüllenformat (`*.dsafe`)
- Auto-Lock nach 5 Minuten Inaktivität
- Clipboard Auto-Clear

## Wichtige Einschränkungen

Dieses Projekt ist als **didaktischer MVP** gedacht.

Es ist **nicht**:

- kompatibel zum offiziellen Password-Safe-Dateiformat `.psafe3`
- sicherheitsauditiert
- gegen alle RAM-/Dump-/Swap-/Malware-Szenarien gehärtet
- für den produktiven Einsatz mit hochkritischen Geheimnissen freigegeben

## Nächste sinnvolle Ausbaustufen

1. Master-Passwort-Dialog als eigenes Formular mit Passwort-Richtlinien
2. Passwortgenerator
3. Kategorien/TreeView statt flacher Liste
4. Import/Export
5. Argon2 statt PBKDF2
6. Bessere Secret-Handling-Strategien im Speicher
7. Digitale Signatur / Integritätsversionierung
8. UI-Polishing und Toolbar / Statusbar
9. Unit-Tests für Crypto- und Storage-Schicht
10. Optional: spätere Annäherung an `.psafe3`-Kompatibilität
