namespace DesktopSafe.Models;

/// <summary>
/// Repräsentiert einen einzelnen Eintrag in der Passwortdatenbank.
/// </summary>
public sealed class PasswordEntry
{
    /// <summary>
    /// Interne eindeutige ID.
    /// </summary>
    public Guid Id { get; set; } = Guid.NewGuid();

    /// <summary>
    /// Gruppe oder Kategorie, z. B. "Arbeit" oder "Privat".
    /// </summary>
    public string Group { get; set; } = string.Empty;

    /// <summary>
    /// Anzeigename des Eintrags.
    /// </summary>
    public string Title { get; set; } = string.Empty;

    /// <summary>
    /// Benutzername oder Login-Name.
    /// </summary>
    public string Username { get; set; } = string.Empty;

    /// <summary>
    /// URL oder Zielsystem.
    /// </summary>
    public string Url { get; set; } = string.Empty;

    /// <summary>
    /// Das eigentliche Passwort.
    /// Für einen echten Produktiveinsatz müsste man mit Klartext im RAM noch vorsichtiger umgehen.
    /// Für ein Lernprojekt halten wir es bewusst verständlich.
    /// </summary>
    public string Password { get; set; } = string.Empty;

    /// <summary>
    /// Freitext-Notizen.
    /// </summary>
    public string Notes { get; set; } = string.Empty;

    /// <summary>
    /// Erstellungszeitpunkt des Eintrags.
    /// </summary>
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Letzter Änderungszeitpunkt des Eintrags.
    /// </summary>
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Liefert einen Text für Listenansichten.
    /// </summary>
    public override string ToString()
    {
        // Bewusst kompakt gehalten, damit die Liste gut lesbar bleibt.
        return string.IsNullOrWhiteSpace(Group)
            ? $"{Title} ({Username})"
            : $"[{Group}] {Title} ({Username})";
    }
}
