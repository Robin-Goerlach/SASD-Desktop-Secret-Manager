namespace DesktopSafe.Models;

/// <summary>
/// Repräsentiert die logisch entschlüsselte Passwortdatenbank im Speicher.
/// </summary>
public sealed class PasswordDatabase
{
    /// <summary>
    /// Anzeigename der Datenbank.
    /// </summary>
    public string DatabaseName { get; set; } = "Meine Safe-Datei";

    /// <summary>
    /// Optionaler Besitzer oder Autor.
    /// </summary>
    public string Owner { get; set; } = Environment.UserName;

    /// <summary>
    /// Zeitpunkt der Erstellung.
    /// </summary>
    public DateTime CreatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Zeitpunkt der letzten Änderung.
    /// </summary>
    public DateTime UpdatedAtUtc { get; set; } = DateTime.UtcNow;

    /// <summary>
    /// Die eigentlichen Passwort-Einträge.
    /// </summary>
    public List<PasswordEntry> Entries { get; set; } = new();
}
