namespace DesktopSafe.Security;

/// <summary>
/// Zentrale Konstanten für kryptografische Parameter.
/// Alles an einer Stelle zu haben erleichtert spätere Anpassungen.
/// </summary>
public static class CryptoConstants
{
    /// <summary>
    /// Länge des AES-Schlüssels in Bytes = 256 Bit.
    /// </summary>
    public const int KeySizeBytes = 32;

    /// <summary>
    /// Salt-Größe für die Schlüsselableitung.
    /// </summary>
    public const int SaltSizeBytes = 16;

    /// <summary>
    /// Nonce-Größe für AES-GCM.
    /// 12 Bytes sind der Standard und effizient.
    /// </summary>
    public const int NonceSizeBytes = 12;

    /// <summary>
    /// Tag-Größe für AES-GCM.
    /// 16 Bytes = 128 Bit.
    /// </summary>
    public const int TagSizeBytes = 16;

    /// <summary>
    /// PBKDF2-Iterationszahl.
    /// Für ein Lernprojekt bewusst klar sichtbar gemacht.
    /// </summary>
    public const int Pbkdf2Iterations = 600_000;
}
