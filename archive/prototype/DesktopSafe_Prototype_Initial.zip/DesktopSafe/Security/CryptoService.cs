using System.Security.Cryptography;
using System.Text;
using System.Text.Json;
using DesktopSafe.Models;
using DesktopSafe.Storage;

namespace DesktopSafe.Security;

/// <summary>
/// Kapselt die komplette Ver- und Entschlüsselung.
/// Die restliche Anwendung soll möglichst wenig über Kryptodetails wissen.
/// </summary>
public sealed class CryptoService
{
    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    /// <summary>
    /// Verschlüsselt die logisch entschlüsselte Datenbank in eine serialisierbare Hülle.
    /// </summary>
    /// <param name="database">Die Datenbank im Klartextmodell.</param>
    /// <param name="masterPassword">Das Master-Passwort des Benutzers.</param>
    /// <returns>Eine verschlüsselte Hülle, die als Datei gespeichert werden kann.</returns>
    public EncryptedFileEnvelope EncryptDatabase(PasswordDatabase database, string masterPassword)
    {
        ArgumentNullException.ThrowIfNull(database);
        ArgumentException.ThrowIfNullOrWhiteSpace(masterPassword);

        // Vor dem Speichern aktualisieren wir den Änderungszeitpunkt.
        database.UpdatedAtUtc = DateTime.UtcNow;

        // Serialisierung der Datenbank in JSON.
        // Für Lernzwecke ist JSON sehr transparent und einfach zu debuggen.
        string json = JsonSerializer.Serialize(database, JsonOptions);
        byte[] plainBytes = Encoding.UTF8.GetBytes(json);

        // Salt und Nonce werden zufällig erzeugt.
        byte[] salt = RandomNumberGenerator.GetBytes(CryptoConstants.SaltSizeBytes);
        byte[] nonce = RandomNumberGenerator.GetBytes(CryptoConstants.NonceSizeBytes);

        // Schlüsselableitung aus Master-Passwort und Salt.
        byte[] key = DeriveKey(masterPassword, salt, CryptoConstants.Pbkdf2Iterations);

        // Zielpuffer für Ciphertext und Auth-Tag.
        byte[] cipherBytes = new byte[plainBytes.Length];
        byte[] tag = new byte[CryptoConstants.TagSizeBytes];

        try
        {
            // AES-GCM verschlüsselt und authentifiziert gleichzeitig.
            using var aes = new AesGcm(key, CryptoConstants.TagSizeBytes);
            aes.Encrypt(nonce, plainBytes, cipherBytes, tag);

            return new EncryptedFileEnvelope
            {
                KdfIterations = CryptoConstants.Pbkdf2Iterations,
                SaltBase64 = Convert.ToBase64String(salt),
                NonceBase64 = Convert.ToBase64String(nonce),
                TagBase64 = Convert.ToBase64String(tag),
                CipherTextBase64 = Convert.ToBase64String(cipherBytes)
            };
        }
        finally
        {
            // Sensible Byte-Arrays soweit möglich überschreiben.
            CryptographicOperations.ZeroMemory(plainBytes);
            CryptographicOperations.ZeroMemory(key);
        }
    }

    /// <summary>
    /// Entschlüsselt eine Dateihülle zurück in das Datenbankmodell.
    /// </summary>
    /// <param name="envelope">Die geladene Dateihülle.</param>
    /// <param name="masterPassword">Das Master-Passwort des Benutzers.</param>
    /// <returns>Die entschlüsselte Datenbank.</returns>
    public PasswordDatabase DecryptDatabase(EncryptedFileEnvelope envelope, string masterPassword)
    {
        ArgumentNullException.ThrowIfNull(envelope);
        ArgumentException.ThrowIfNullOrWhiteSpace(masterPassword);

        if (!string.Equals(envelope.Format, "DesktopSafe/1", StringComparison.Ordinal))
        {
            throw new InvalidOperationException("Unbekanntes oder nicht unterstütztes Dateiformat.");
        }

        if (!string.Equals(envelope.KdfAlgorithm, "PBKDF2-SHA256", StringComparison.Ordinal))
        {
            throw new InvalidOperationException("Unbekanntes oder nicht unterstütztes KDF-Verfahren.");
        }

        byte[] salt = Convert.FromBase64String(envelope.SaltBase64);
        byte[] nonce = Convert.FromBase64String(envelope.NonceBase64);
        byte[] tag = Convert.FromBase64String(envelope.TagBase64);
        byte[] cipherBytes = Convert.FromBase64String(envelope.CipherTextBase64);

        byte[] key = DeriveKey(masterPassword, salt, envelope.KdfIterations);
        byte[] plainBytes = new byte[cipherBytes.Length];

        try
        {
            using var aes = new AesGcm(key, CryptoConstants.TagSizeBytes);
            aes.Decrypt(nonce, cipherBytes, tag, plainBytes);

            string json = Encoding.UTF8.GetString(plainBytes);
            PasswordDatabase? database = JsonSerializer.Deserialize<PasswordDatabase>(json);

            return database ?? throw new InvalidOperationException("Datei konnte zwar entschlüsselt werden, enthielt aber keine gültige Datenbank.");
        }
        catch (CryptographicException)
        {
            // Kryptofehler bedeuten hier typischerweise: falsches Passwort oder manipulierte Datei.
            throw new InvalidOperationException("Entschlüsselung fehlgeschlagen. Möglicherweise ist das Master-Passwort falsch oder die Datei wurde beschädigt.");
        }
        finally
        {
            CryptographicOperations.ZeroMemory(key);
            CryptographicOperations.ZeroMemory(plainBytes);
        }
    }

    /// <summary>
    /// Leitet einen 256-Bit-Schlüssel aus dem Master-Passwort ab.
    /// </summary>
    /// <param name="masterPassword">Das Master-Passwort.</param>
    /// <param name="salt">Zufälliger Salt.</param>
    /// <param name="iterations">Iterationszahl für PBKDF2.</param>
    /// <returns>Der abgeleitete Schlüssel.</returns>
    private static byte[] DeriveKey(string masterPassword, byte[] salt, int iterations)
    {
        // PBKDF2 ist in .NET direkt verfügbar und daher für ein sauberes Lernprojekt praktisch.
        return Rfc2898DeriveBytes.Pbkdf2(
            masterPassword,
            salt,
            iterations,
            HashAlgorithmName.SHA256,
            CryptoConstants.KeySizeBytes);
    }
}
