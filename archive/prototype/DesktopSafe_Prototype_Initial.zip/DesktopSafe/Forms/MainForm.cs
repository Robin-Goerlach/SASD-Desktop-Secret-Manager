using DesktopSafe.Models;
using DesktopSafe.Storage;
using DesktopSafe.Utils;

namespace DesktopSafe.Forms;

/// <summary>
/// Hauptfenster der Anwendung.
/// Dieses Formular koordiniert Dateioperationen, Anzeige und Benutzeraktionen.
/// </summary>
public sealed class MainForm : Form
{
    private readonly SafeFileService _safeFileService = new();

    private PasswordDatabase? _currentDatabase;
    private string? _currentFilePath;
    private string? _currentMasterPassword;

    private readonly ListBox _entryListBox = new();
    private readonly TextBox _detailsTextBox = new();
    private readonly TextBox _searchTextBox = new();
    private readonly Timer _autoLockTimer = new();

    /// <summary>
    /// Erstellt das Hauptfenster.
    /// </summary>
    public MainForm()
    {
        Text = "DesktopSafe – Password-Safe-inspirierter C# Desktop Clone";
        Width = 1100;
        Height = 700;
        StartPosition = FormStartPosition.CenterScreen;

        BuildMenu();
        BuildLayout();
        ConfigureAutoLock();
        UpdateUiState();
    }

    /// <summary>
    /// Baut die Menüleiste auf.
    /// </summary>
    private void BuildMenu()
    {
        MenuStrip menuStrip = new();

        ToolStripMenuItem fileMenu = new("Datei");
        fileMenu.DropDownItems.Add("Neu", null, (_, _) => CreateNewDatabase());
        fileMenu.DropDownItems.Add("Öffnen", null, (_, _) => OpenDatabase());
        fileMenu.DropDownItems.Add("Speichern", null, (_, _) => SaveDatabase());
        fileMenu.DropDownItems.Add("Speichern unter", null, (_, _) => SaveDatabaseAs());
        fileMenu.DropDownItems.Add(new ToolStripSeparator());
        fileMenu.DropDownItems.Add("Sperren", null, (_, _) => LockDatabase());
        fileMenu.DropDownItems.Add(new ToolStripSeparator());
        fileMenu.DropDownItems.Add("Beenden", null, (_, _) => Close());

        ToolStripMenuItem entryMenu = new("Einträge");
        entryMenu.DropDownItems.Add("Neu", null, (_, _) => AddEntry());
        entryMenu.DropDownItems.Add("Bearbeiten", null, (_, _) => EditSelectedEntry());
        entryMenu.DropDownItems.Add("Löschen", null, (_, _) => DeleteSelectedEntry());
        entryMenu.DropDownItems.Add(new ToolStripSeparator());
        entryMenu.DropDownItems.Add("Benutzername kopieren", null, async (_, _) => await CopySelectedUsernameAsync());
        entryMenu.DropDownItems.Add("Passwort kopieren", null, async (_, _) => await CopySelectedPasswordAsync());

        ToolStripMenuItem helpMenu = new("Hilfe");
        helpMenu.DropDownItems.Add("Über", null, (_, _) => ShowAbout());

        menuStrip.Items.Add(fileMenu);
        menuStrip.Items.Add(entryMenu);
        menuStrip.Items.Add(helpMenu);

        MainMenuStrip = menuStrip;
        Controls.Add(menuStrip);
    }

    /// <summary>
    /// Baut die sichtbare Oberfläche.
    /// </summary>
    private void BuildLayout()
    {
        SplitContainer splitContainer = new()
        {
            Dock = DockStyle.Fill,
            SplitterDistance = 380
        };

        Panel leftPanel = new() { Dock = DockStyle.Fill, Padding = new Padding(8) };
        Panel rightPanel = new() { Dock = DockStyle.Fill, Padding = new Padding(8) };

        FlowLayoutPanel topLeftPanel = new()
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true
        };

        _searchTextBox.Width = 240;
        _searchTextBox.PlaceholderText = "Suche nach Titel, Gruppe, Benutzername ...";
        _searchTextBox.TextChanged += (_, _) => RefreshEntryList();

        Button addButton = new() { Text = "Neu", AutoSize = true };
        addButton.Click += (_, _) => AddEntry();

        Button editButton = new() { Text = "Bearbeiten", AutoSize = true };
        editButton.Click += (_, _) => EditSelectedEntry();

        Button deleteButton = new() { Text = "Löschen", AutoSize = true };
        deleteButton.Click += (_, _) => DeleteSelectedEntry();

        topLeftPanel.Controls.AddRange([_searchTextBox, addButton, editButton, deleteButton]);

        _entryListBox.Dock = DockStyle.Fill;
        _entryListBox.HorizontalScrollbar = true;
        _entryListBox.SelectedIndexChanged += (_, _) => ShowSelectedEntryDetails();
        _entryListBox.DoubleClick += (_, _) => EditSelectedEntry();

        leftPanel.Controls.Add(_entryListBox);
        leftPanel.Controls.Add(topLeftPanel);

        FlowLayoutPanel topRightPanel = new()
        {
            Dock = DockStyle.Top,
            AutoSize = true,
            FlowDirection = FlowDirection.LeftToRight,
            WrapContents = true
        };

        Button copyUserButton = new() { Text = "Benutzername kopieren", AutoSize = true };
        copyUserButton.Click += async (_, _) => await CopySelectedUsernameAsync();

        Button copyPasswordButton = new() { Text = "Passwort kopieren", AutoSize = true };
        copyPasswordButton.Click += async (_, _) => await CopySelectedPasswordAsync();

        Button saveButton = new() { Text = "Speichern", AutoSize = true };
        saveButton.Click += (_, _) => SaveDatabase();

        topRightPanel.Controls.AddRange([copyUserButton, copyPasswordButton, saveButton]);

        _detailsTextBox.Dock = DockStyle.Fill;
        _detailsTextBox.Multiline = true;
        _detailsTextBox.ReadOnly = true;
        _detailsTextBox.ScrollBars = ScrollBars.Vertical;
        _detailsTextBox.Font = new Font("Consolas", 10);

        rightPanel.Controls.Add(_detailsTextBox);
        rightPanel.Controls.Add(topRightPanel);

        splitContainer.Panel1.Controls.Add(leftPanel);
        splitContainer.Panel2.Controls.Add(rightPanel);

        Controls.Add(splitContainer);
    }

    /// <summary>
    /// Konfiguriert Auto-Lock nach Inaktivität.
    /// </summary>
    private void ConfigureAutoLock()
    {
        // 5 Minuten Demo-Timeout.
        _autoLockTimer.Interval = (int)TimeSpan.FromMinutes(5).TotalMilliseconds;
        _autoLockTimer.Tick += (_, _) =>
        {
            _autoLockTimer.Stop();
            if (_currentDatabase is not null)
            {
                MessageBox.Show(this, "Die Datenbank wurde nach Inaktivität gesperrt.", "Auto-Lock", MessageBoxButtons.OK, MessageBoxIcon.Information);
                LockDatabase();
            }
        };

        // Mehrere UI-Events zurücksetzen, damit der Timer bei Aktivität neu startet.
        foreach (Control control in GetAllControls(this))
        {
            control.MouseMove += (_, _) => ResetAutoLockTimer();
            control.KeyDown += (_, _) => ResetAutoLockTimer();
        }
    }

    /// <summary>
    /// Rekursives Einsammeln aller Controls.
    /// </summary>
    private static IEnumerable<Control> GetAllControls(Control root)
    {
        foreach (Control child in root.Controls)
        {
            yield return child;
            foreach (Control nested in GetAllControls(child))
            {
                yield return nested;
            }
        }
    }

    /// <summary>
    /// Startet oder erneuert den Auto-Lock-Timer.
    /// </summary>
    private void ResetAutoLockTimer()
    {
        if (_currentDatabase is null)
        {
            return;
        }

        _autoLockTimer.Stop();
        _autoLockTimer.Start();
    }

    /// <summary>
    /// Legt eine neue leere Datenbank an.
    /// </summary>
    private void CreateNewDatabase()
    {
        string? masterPassword = Prompt.ShowDialog("Neue Datenbank", "Bitte Master-Passwort eingeben:", true);
        if (string.IsNullOrWhiteSpace(masterPassword))
        {
            return;
        }

        string? confirmation = Prompt.ShowDialog("Neue Datenbank", "Bitte Master-Passwort wiederholen:", true);
        if (!string.Equals(masterPassword, confirmation, StringComparison.Ordinal))
        {
            MessageBox.Show(this, "Die Passwörter stimmen nicht überein.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        _currentDatabase = new PasswordDatabase();
        _currentMasterPassword = masterPassword;
        _currentFilePath = null;

        RefreshEntryList();
        ShowSelectedEntryDetails();
        UpdateUiState();
        ResetAutoLockTimer();

        MessageBox.Show(this, "Neue Datenbank wurde im Speicher angelegt. Bitte speichern Sie sie als Datei.", "Info", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }

    /// <summary>
    /// Öffnet eine bestehende Datei.
    /// </summary>
    private void OpenDatabase()
    {
        using OpenFileDialog dialog = new()
        {
            Filter = "DesktopSafe Dateien (*.dsafe)|*.dsafe|Alle Dateien (*.*)|*.*"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        string? masterPassword = Prompt.ShowDialog("Datenbank öffnen", "Master-Passwort eingeben:", true);
        if (string.IsNullOrWhiteSpace(masterPassword))
        {
            return;
        }

        try
        {
            _currentDatabase = _safeFileService.Load(dialog.FileName, masterPassword);
            _currentFilePath = dialog.FileName;
            _currentMasterPassword = masterPassword;

            RefreshEntryList();
            ShowSelectedEntryDetails();
            UpdateUiState();
            ResetAutoLockTimer();
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Öffnen fehlgeschlagen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    /// <summary>
    /// Speichert die Datenbank in die aktuelle Datei oder fragt einen neuen Pfad ab.
    /// </summary>
    private void SaveDatabase()
    {
        if (_currentDatabase is null)
        {
            MessageBox.Show(this, "Es ist keine Datenbank geöffnet.", "Hinweis", MessageBoxButtons.OK, MessageBoxIcon.Information);
            return;
        }

        if (string.IsNullOrWhiteSpace(_currentMasterPassword))
        {
            MessageBox.Show(this, "Kein Master-Passwort im Speicher vorhanden.", "Fehler", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }

        if (string.IsNullOrWhiteSpace(_currentFilePath))
        {
            SaveDatabaseAs();
            return;
        }

        try
        {
            _safeFileService.Save(_currentFilePath, _currentDatabase, _currentMasterPassword);
            Text = $"DesktopSafe – {_currentFilePath}";
            MessageBox.Show(this, "Datenbank wurde gespeichert.", "Speichern", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }
        catch (Exception ex)
        {
            MessageBox.Show(this, ex.Message, "Speichern fehlgeschlagen", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }
    }

    /// <summary>
    /// Speichern unter mit Dateiauswahl.
    /// </summary>
    private void SaveDatabaseAs()
    {
        if (_currentDatabase is null)
        {
            return;
        }

        using SaveFileDialog dialog = new()
        {
            Filter = "DesktopSafe Dateien (*.dsafe)|*.dsafe|Alle Dateien (*.*)|*.*",
            DefaultExt = "dsafe"
        };

        if (dialog.ShowDialog(this) != DialogResult.OK)
        {
            return;
        }

        _currentFilePath = dialog.FileName;
        SaveDatabase();
    }

    /// <summary>
    /// Sperrt die Datenbank, indem die Klartextdaten aus der UI entfernt werden.
    /// </summary>
    private void LockDatabase()
    {
        _currentDatabase = null;
        _currentMasterPassword = null;
        _entryListBox.Items.Clear();
        _detailsTextBox.Clear();
        _searchTextBox.Clear();
        _autoLockTimer.Stop();
        UpdateUiState();
        Text = "DesktopSafe – Gesperrt";
    }

    /// <summary>
    /// Fügt einen neuen Eintrag hinzu.
    /// </summary>
    private void AddEntry()
    {
        if (_currentDatabase is null)
        {
            return;
        }

        using EntryEditorForm dialog = new();
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.ResultEntry is null)
        {
            return;
        }

        _currentDatabase.Entries.Add(dialog.ResultEntry);
        _currentDatabase.UpdatedAtUtc = DateTime.UtcNow;
        RefreshEntryList();
        SelectEntryById(dialog.ResultEntry.Id);
        ResetAutoLockTimer();
    }

    /// <summary>
    /// Bearbeitet den aktuell ausgewählten Eintrag.
    /// </summary>
    private void EditSelectedEntry()
    {
        if (_currentDatabase is null)
        {
            return;
        }

        PasswordEntry? selectedEntry = GetSelectedEntry();
        if (selectedEntry is null)
        {
            return;
        }

        using EntryEditorForm dialog = new(selectedEntry);
        if (dialog.ShowDialog(this) != DialogResult.OK || dialog.ResultEntry is null)
        {
            return;
        }

        int index = _currentDatabase.Entries.FindIndex(entry => entry.Id == selectedEntry.Id);
        if (index >= 0)
        {
            _currentDatabase.Entries[index] = dialog.ResultEntry;
            _currentDatabase.UpdatedAtUtc = DateTime.UtcNow;
        }

        RefreshEntryList();
        SelectEntryById(dialog.ResultEntry.Id);
        ResetAutoLockTimer();
    }

    /// <summary>
    /// Löscht den aktuell ausgewählten Eintrag.
    /// </summary>
    private void DeleteSelectedEntry()
    {
        if (_currentDatabase is null)
        {
            return;
        }

        PasswordEntry? selectedEntry = GetSelectedEntry();
        if (selectedEntry is null)
        {
            return;
        }

        DialogResult result = MessageBox.Show(
            this,
            $"Soll der Eintrag '{selectedEntry.Title}' wirklich gelöscht werden?",
            "Löschen bestätigen",
            MessageBoxButtons.YesNo,
            MessageBoxIcon.Question);

        if (result != DialogResult.Yes)
        {
            return;
        }

        _currentDatabase.Entries.RemoveAll(entry => entry.Id == selectedEntry.Id);
        _currentDatabase.UpdatedAtUtc = DateTime.UtcNow;
        RefreshEntryList();
        ShowSelectedEntryDetails();
        ResetAutoLockTimer();
    }

    /// <summary>
    /// Baut die linke Eintragsliste entsprechend Suchbegriff neu auf.
    /// </summary>
    private void RefreshEntryList()
    {
        _entryListBox.BeginUpdate();
        _entryListBox.Items.Clear();

        if (_currentDatabase is null)
        {
            _entryListBox.EndUpdate();
            return;
        }

        string term = _searchTextBox.Text.Trim();

        IEnumerable<PasswordEntry> filteredEntries = _currentDatabase.Entries
            .OrderBy(entry => entry.Group)
            .ThenBy(entry => entry.Title)
            .Where(entry =>
                string.IsNullOrWhiteSpace(term) ||
                entry.Title.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                entry.Group.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                entry.Username.Contains(term, StringComparison.OrdinalIgnoreCase) ||
                entry.Url.Contains(term, StringComparison.OrdinalIgnoreCase));

        foreach (PasswordEntry entry in filteredEntries)
        {
            _entryListBox.Items.Add(entry);
        }

        _entryListBox.EndUpdate();
        UpdateUiState();
    }

    /// <summary>
    /// Zeigt die Details des ausgewählten Eintrags im rechten Panel an.
    /// </summary>
    private void ShowSelectedEntryDetails()
    {
        PasswordEntry? entry = GetSelectedEntry();

        if (entry is null)
        {
            _detailsTextBox.Text = _currentDatabase is null
                ? "Keine Datenbank geöffnet."
                : "Kein Eintrag ausgewählt.";
            return;
        }

        // Passwort wird absichtlich nicht automatisch im Klartext angezeigt.
        _detailsTextBox.Text = $@"Gruppe:      {entry.Group}
Titel:       {entry.Title}
Benutzer:    {entry.Username}
URL:         {entry.Url}
Passwort:    ********
Erstellt:    {entry.CreatedAtUtc:u}
Geändert:    {entry.UpdatedAtUtc:u}

Notizen:
{entry.Notes}";
    }

    /// <summary>
    /// Kopiert den Benutzernamen des gewählten Eintrags.
    /// </summary>
    private async Task CopySelectedUsernameAsync()
    {
        PasswordEntry? entry = GetSelectedEntry();
        if (entry is null || string.IsNullOrWhiteSpace(entry.Username))
        {
            return;
        }

        await ClipboardHelper.CopyTextTemporarilyAsync(entry.Username, TimeSpan.FromSeconds(20));
        MessageBox.Show(this, "Benutzername wurde für 20 Sekunden in die Zwischenablage kopiert.", "Zwischenablage", MessageBoxButtons.OK, MessageBoxIcon.Information);
        ResetAutoLockTimer();
    }

    /// <summary>
    /// Kopiert das Passwort des gewählten Eintrags.
    /// </summary>
    private async Task CopySelectedPasswordAsync()
    {
        PasswordEntry? entry = GetSelectedEntry();
        if (entry is null || string.IsNullOrEmpty(entry.Password))
        {
            return;
        }

        await ClipboardHelper.CopyTextTemporarilyAsync(entry.Password, TimeSpan.FromSeconds(15));
        MessageBox.Show(this, "Passwort wurde für 15 Sekunden in die Zwischenablage kopiert.", "Zwischenablage", MessageBoxButtons.OK, MessageBoxIcon.Information);
        ResetAutoLockTimer();
    }

    /// <summary>
    /// Liefert den aktuell ausgewählten Eintrag oder null.
    /// </summary>
    private PasswordEntry? GetSelectedEntry()
    {
        return _entryListBox.SelectedItem as PasswordEntry;
    }

    /// <summary>
    /// Wählt einen Eintrag nach ID wieder an.
    /// Praktisch nach Bearbeiten oder Neu-Anlegen.
    /// </summary>
    private void SelectEntryById(Guid entryId)
    {
        for (int i = 0; i < _entryListBox.Items.Count; i++)
        {
            if (_entryListBox.Items[i] is PasswordEntry entry && entry.Id == entryId)
            {
                _entryListBox.SelectedIndex = i;
                return;
            }
        }
    }

    /// <summary>
    /// Aktiviert bzw. deaktiviert UI-Teile abhängig vom Zustand.
    /// </summary>
    private void UpdateUiState()
    {
        bool hasDatabase = _currentDatabase is not null;
        _searchTextBox.Enabled = hasDatabase;
        _entryListBox.Enabled = hasDatabase;
        _detailsTextBox.Enabled = hasDatabase;
    }

    /// <summary>
    /// Zeigt Informationen über dieses Lernprojekt an.
    /// </summary>
    private void ShowAbout()
    {
        MessageBox.Show(
            this,
            "DesktopSafe\n\n" +
            "Ein bewusst überschaubarer, sauber strukturierter, Password-Safe-inspirierter C# Desktop-Prototyp.\n\n" +
            "Wichtig: Dieses Beispiel ist ein Lern- und Architekturprojekt, kein fertig auditiertes Security-Produkt.\n\n" +
            "Merkmale:\n- AES-256-GCM\n- PBKDF2-SHA256\n- verschlüsselte JSON-Datei\n- Auto-Lock\n- Clipboard Auto-Clear",
            "Über DesktopSafe",
            MessageBoxButtons.OK,
            MessageBoxIcon.Information);
    }
}
