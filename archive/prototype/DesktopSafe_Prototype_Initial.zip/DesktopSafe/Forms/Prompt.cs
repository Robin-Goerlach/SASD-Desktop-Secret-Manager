namespace DesktopSafe.Forms;

/// <summary>
/// Kleine Hilfsklasse für einfache Eingabedialoge.
/// So bleiben die Hauptformulare lesbarer.
/// </summary>
public static class Prompt
{
    /// <summary>
    /// Fragt eine einfache Texteingabe ab.
    /// </summary>
    public static string? ShowDialog(string title, string label, bool usePasswordChar = false)
    {
        using Form form = new()
        {
            Text = title,
            StartPosition = FormStartPosition.CenterParent,
            FormBorderStyle = FormBorderStyle.FixedDialog,
            MinimizeBox = false,
            MaximizeBox = false,
            Width = 450,
            Height = 170
        };

        Label promptLabel = new()
        {
            Left = 12,
            Top = 15,
            Width = 400,
            Text = label
        };

        TextBox textBox = new()
        {
            Left = 12,
            Top = 40,
            Width = 400,
            UseSystemPasswordChar = usePasswordChar
        };

        Button okButton = new()
        {
            Text = "OK",
            Left = 240,
            Width = 80,
            Top = 80,
            DialogResult = DialogResult.OK
        };

        Button cancelButton = new()
        {
            Text = "Abbrechen",
            Left = 332,
            Width = 80,
            Top = 80,
            DialogResult = DialogResult.Cancel
        };

        form.Controls.AddRange([promptLabel, textBox, okButton, cancelButton]);
        form.AcceptButton = okButton;
        form.CancelButton = cancelButton;

        return form.ShowDialog() == DialogResult.OK ? textBox.Text : null;
    }
}
