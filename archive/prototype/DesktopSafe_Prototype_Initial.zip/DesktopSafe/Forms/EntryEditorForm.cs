using DesktopSafe.Models;

namespace DesktopSafe.Forms;

/// <summary>
/// Formular zum Anlegen oder Bearbeiten eines einzelnen Eintrags.
/// </summary>
public sealed class EntryEditorForm : Form
{
    private readonly TextBox _groupTextBox = new();
    private readonly TextBox _titleTextBox = new();
    private readonly TextBox _usernameTextBox = new();
    private readonly TextBox _urlTextBox = new();
    private readonly TextBox _passwordTextBox = new();
    private readonly TextBox _notesTextBox = new();

    /// <summary>
    /// Das Ergebnis nach erfolgreichem Speichern.
    /// </summary>
    public PasswordEntry? ResultEntry { get; private set; }

    /// <summary>
    /// Erstellt den Dialog.
    /// </summary>
    public EntryEditorForm(PasswordEntry? sourceEntry = null)
    {
        Text = sourceEntry is null ? "Neuen Eintrag anlegen" : "Eintrag bearbeiten";
        Width = 700;
        Height = 520;
        StartPosition = FormStartPosition.CenterParent;

        // TableLayoutPanel ist hier praktisch, weil Labels und Eingabefelder sauber ausgerichtet werden.
        TableLayoutPanel layout = new()
        {
            Dock = DockStyle.Fill,
            ColumnCount = 2,
            RowCount = 7,
            Padding = new Padding(12),
            AutoSize = true
        };

        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Absolute, 140));
        layout.ColumnStyles.Add(new ColumnStyle(SizeType.Percent, 100));

        AddRow(layout, 0, "Gruppe:", _groupTextBox);
        AddRow(layout, 1, "Titel*:", _titleTextBox);
        AddRow(layout, 2, "Benutzername:", _usernameTextBox);
        AddRow(layout, 3, "URL:", _urlTextBox);

        _passwordTextBox.UseSystemPasswordChar = true;
        AddRow(layout, 4, "Passwort:", _passwordTextBox);

        _notesTextBox.Multiline = true;
        _notesTextBox.ScrollBars = ScrollBars.Vertical;
        _notesTextBox.Height = 180;
        AddRow(layout, 5, "Notizen:", _notesTextBox, true);

        FlowLayoutPanel buttonPanel = new()
        {
            Dock = DockStyle.Fill,
            FlowDirection = FlowDirection.RightToLeft,
            AutoSize = true
        };

        Button saveButton = new()
        {
            Text = "Speichern",
            AutoSize = true
        };
        saveButton.Click += (_, _) => SaveEntry(sourceEntry);

        Button cancelButton = new()
        {
            Text = "Abbrechen",
            AutoSize = true,
            DialogResult = DialogResult.Cancel
        };

        Button togglePasswordButton = new()
        {
            Text = "Passwort zeigen/verbergen",
            AutoSize = true
        };
        togglePasswordButton.Click += (_, _) => _passwordTextBox.UseSystemPasswordChar = !_passwordTextBox.UseSystemPasswordChar;

        buttonPanel.Controls.Add(saveButton);
        buttonPanel.Controls.Add(cancelButton);
        buttonPanel.Controls.Add(togglePasswordButton);
        layout.Controls.Add(buttonPanel, 1, 6);

        Controls.Add(layout);

        AcceptButton = saveButton;
        CancelButton = cancelButton;

        if (sourceEntry is not null)
        {
            // Beim Bearbeiten vorhandene Daten übernehmen.
            _groupTextBox.Text = sourceEntry.Group;
            _titleTextBox.Text = sourceEntry.Title;
            _usernameTextBox.Text = sourceEntry.Username;
            _urlTextBox.Text = sourceEntry.Url;
            _passwordTextBox.Text = sourceEntry.Password;
            _notesTextBox.Text = sourceEntry.Notes;
        }
    }

    /// <summary>
    /// Fügt dem Layout eine Zeile aus Label und Control hinzu.
    /// </summary>
    private static void AddRow(TableLayoutPanel layout, int row, string labelText, Control control, bool fillHeight = false)
    {
        Label label = new()
        {
            Text = labelText,
            AutoSize = true,
            Anchor = AnchorStyles.Left | AnchorStyles.Top,
            Margin = new Padding(0, 8, 6, 8)
        };

        control.Dock = DockStyle.Top;
        control.Margin = new Padding(0, 4, 0, 8);

        if (fillHeight)
        {
            control.Dock = DockStyle.Fill;
            layout.RowStyles.Add(new RowStyle(SizeType.Percent, 100));
        }
        else
        {
            layout.RowStyles.Add(new RowStyle(SizeType.AutoSize));
        }

        layout.Controls.Add(label, 0, row);
        layout.Controls.Add(control, 1, row);
    }

    /// <summary>
    /// Validiert die Eingaben und erstellt das Ergebnisobjekt.
    /// </summary>
    private void SaveEntry(PasswordEntry? sourceEntry)
    {
        if (string.IsNullOrWhiteSpace(_titleTextBox.Text))
        {
            MessageBox.Show(this, "Ein Titel ist erforderlich.", "Validierung", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            return;
        }

        ResultEntry = new PasswordEntry
        {
            // Beim Bearbeiten behalten wir die ID und das CreatedAt bei.
            Id = sourceEntry?.Id ?? Guid.NewGuid(),
            CreatedAtUtc = sourceEntry?.CreatedAtUtc ?? DateTime.UtcNow,
            UpdatedAtUtc = DateTime.UtcNow,
            Group = _groupTextBox.Text.Trim(),
            Title = _titleTextBox.Text.Trim(),
            Username = _usernameTextBox.Text.Trim(),
            Url = _urlTextBox.Text.Trim(),
            Password = _passwordTextBox.Text,
            Notes = _notesTextBox.Text
        };

        DialogResult = DialogResult.OK;
        Close();
    }
}
