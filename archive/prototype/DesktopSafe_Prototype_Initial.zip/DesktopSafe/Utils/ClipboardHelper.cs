namespace DesktopSafe.Utils;

/// <summary>
/// Hilfsfunktionen rund um die Zwischenablage.
/// </summary>
public static class ClipboardHelper
{
    /// <summary>
    /// Kopiert Text in die Zwischenablage und leert sie nach einer definierten Zeit wieder,
    /// sofern der gleiche Text noch dort liegt.
    /// </summary>
    public static async Task CopyTextTemporarilyAsync(string text, TimeSpan duration)
    {
        if (string.IsNullOrEmpty(text))
        {
            return;
        }

        Clipboard.SetText(text);

        // Warten im Hintergrund, ohne die UI zu blockieren.
        await Task.Delay(duration);

        try
        {
            // Nur dann löschen, wenn unser Text noch drin liegt.
            // So zerstören wir nicht versehentlich bereits neu kopierte Inhalte des Nutzers.
            if (Clipboard.ContainsText() && Clipboard.GetText() == text)
            {
                Clipboard.Clear();
            }
        }
        catch
        {
            // Zwischenablage kann durch andere Prozesse gesperrt sein.
            // Für das Lernprojekt ignorieren wir den Fehler bewusst.
        }
    }
}
