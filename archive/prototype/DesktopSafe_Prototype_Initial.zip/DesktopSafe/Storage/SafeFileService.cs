using System.Text.Json;
using DesktopSafe.Models;
using DesktopSafe.Security;

namespace DesktopSafe.Storage;

/// <summary>
/// Kapselt Dateizugriffe.
/// Die Formulare arbeiten dadurch nicht direkt mit JSON und Kryptologik.
/// </summary>
public sealed class SafeFileService
{
    private readonly CryptoService _cryptoService = new();

    private static readonly JsonSerializerOptions JsonOptions = new()
    {
        WriteIndented = true
    };

    /// <summary>
    /// Speichert die Datenbank verschlüsselt in eine Datei.
    /// </summary>
    public void Save(string filePath, PasswordDatabase database, string masterPassword)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);
        ArgumentNullException.ThrowIfNull(database);
        ArgumentException.ThrowIfNullOrWhiteSpace(masterPassword);

        EncryptedFileEnvelope envelope = _cryptoService.EncryptDatabase(database, masterPassword);
        string json = JsonSerializer.Serialize(envelope, JsonOptions);
        File.WriteAllText(filePath, json);
    }

    /// <summary>
    /// Lädt die verschlüsselte Datei und entschlüsselt sie.
    /// </summary>
    public PasswordDatabase Load(string filePath, string masterPassword)
    {
        ArgumentException.ThrowIfNullOrWhiteSpace(filePath);
        ArgumentException.ThrowIfNullOrWhiteSpace(masterPassword);

        string json = File.ReadAllText(filePath);
        EncryptedFileEnvelope? envelope = JsonSerializer.Deserialize<EncryptedFileEnvelope>(json);

        if (envelope is null)
        {
            throw new InvalidOperationException("Die Datei enthält kein gültiges DesktopSafe-Format.");
        }

        return _cryptoService.DecryptDatabase(envelope, masterPassword);
    }
}
