namespace DesktopSafe.Storage;

/// <summary>
/// Hülle für die verschlüsselte Datei.
/// Diese Klasse enthält nur Metadaten und Ciphertext.
/// </summary>
public sealed class EncryptedFileEnvelope
{
    /// <summary>
    /// Eigenes Dateiformat / Versionskennung.
    /// Damit können spätere Versionen erkennen, was sie vor sich haben.
    /// </summary>
    public string Format { get; set; } = "DesktopSafe/1";

    /// <summary>
    /// Name des Key-Derivation-Verfahrens.
    /// </summary>
    public string KdfAlgorithm { get; set; } = "PBKDF2-SHA256";

    /// <summary>
    /// Iterationszahl für PBKDF2.
    /// </summary>
    public int KdfIterations { get; set; }

    /// <summary>
    /// Salt für die Schlüsselableitung, Base64-kodiert.
    /// </summary>
    public string SaltBase64 { get; set; } = string.Empty;

    /// <summary>
    /// Nonce / IV für AES-GCM, Base64-kodiert.
    /// </summary>
    public string NonceBase64 { get; set; } = string.Empty;

    /// <summary>
    /// Authentifizierungstag für AES-GCM, Base64-kodiert.
    /// </summary>
    public string TagBase64 { get; set; } = string.Empty;

    /// <summary>
    /// Verschlüsselte JSON-Nutzdaten, Base64-kodiert.
    /// </summary>
    public string CipherTextBase64 { get; set; } = string.Empty;
}
