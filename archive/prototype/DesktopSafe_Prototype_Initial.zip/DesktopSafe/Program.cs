using DesktopSafe.Forms;

namespace DesktopSafe;

/// <summary>
/// Einstiegspunkt der Anwendung.
/// </summary>
internal static class Program
{
    /// <summary>
    /// Startet die WinForms-Anwendung.
    /// </summary>
    [STAThread]
    private static void Main()
    {
        // Aktiviert moderne WinForms-Defaults wie High DPI und Standard-Fonts.
        ApplicationConfiguration.Initialize();

        // Startet direkt das Hauptfenster.
        Application.Run(new MainForm());
    }
}
