using Sasd.SecretManager.Application;
using Sasd.SecretManager.Domain;
using Xunit;

// ============================================================================
// Dateiüberblick:
// Enthält Unit-Tests zur Verifikation des beschriebenen Fach- und UI-nahen Verhaltens.
// Die Testnamen sind sprechend gewählt und dienen zugleich als Dokumentation
// des erwarteten Verhaltens der produktiven Klassen.
// ============================================================================

namespace Sasd.SecretManager.Application.Tests;

/// <summary>
    /// Testklasse für EntryMutationService und das dazugehörige erwartete Verhalten.
    /// </summary>
public sealed class EntryMutationServiceTests
{
    /// <summary>
    /// Verifiziert: CreateEntry AddsEntryTagsAndCustomFields.
    /// </summary>
    [Fact]
    public void CreateEntry_AddsEntryTagsAndCustomFields()
    {
        var vault = new DemoVaultFactory().CreateDemoVault();
        var service = new EntryMutationService();

        var model = new EntryEditModel
        {
            Title = "Neuer API Zugang",
            EntryType = EntryType.ApiKey,
            UserName = "api-user",
            Secret = "Api-Example!2026#Token",
            SelectedGroupPath = "SASD-GmbH/GitHub",
            TagsText = "SASD, API, GitHub",
            Notes = "Testeintrag",
            CustomFieldsText = "URL = https://api.example.invalid\n!Client Secret = secret-123",
        };

        var entry = service.CreateEntry(vault, model);

        Assert.Contains(entry, vault.Entries);
        Assert.Equal(EntryType.ApiKey, entry.EntryType);
        Assert.Equal("api-user", entry.UserName);
        Assert.Contains("API", entry.Tags);
        Assert.Equal(2, entry.CustomFields.Count);
        Assert.True(entry.CustomFields[1].IsSecret);
    }

    /// <summary>
    /// Verifiziert: UpdateEntry ReplacesTagsAndChangesModifiedTimestamp.
    /// </summary>
    [Fact]
    public void UpdateEntry_ReplacesTagsAndChangesModifiedTimestamp()
    {
        var vault = new DemoVaultFactory().CreateDemoVault();
        var service = new EntryMutationService();
        var entry = vault.Entries[0];
        var oldModified = entry.ModifiedUtc;

        var model = EntryEditModel.FromEntry(entry, "SASD-GmbH/IONOS");
        model.TagsText = "SASD, IONOS, Deployment";
        model.Title = "IONOS Webspace FTP Bearbeitet";

        var changed = service.UpdateEntry(vault, entry, model);

        Assert.True(changed);
        Assert.Equal("IONOS Webspace FTP Bearbeitet", entry.Title);
        Assert.DoesNotContain("FTP", entry.Tags);
        Assert.Contains("Deployment", entry.Tags);
        Assert.True(entry.ModifiedUtc >= oldModified);
    }

    /// <summary>
    /// Verifiziert: UpdateEntry ReturnsFalseWhenModelHasNoEffectiveChanges.
    /// </summary>
    [Fact]
    public void UpdateEntry_ReturnsFalseWhenModelHasNoEffectiveChanges()
    {
        var vault = new DemoVaultFactory().CreateDemoVault();
        var service = new EntryMutationService();
        var entry = vault.Entries[0];
        var oldModified = entry.ModifiedUtc;
        var currentGroupPath = vault.Groups.Single(group => group.Id == entry.GroupId).Path;

        var model = EntryEditModel.FromEntry(entry, currentGroupPath);

        var changed = service.UpdateEntry(vault, entry, model);

        Assert.False(changed);
        Assert.Equal(oldModified, entry.ModifiedUtc);
    }
}
